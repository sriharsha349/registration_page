## JavaFX Registration Form Example

The Project explains how to create a Registration form in JavaFX.
Compile and run `RegistrationFormApplication.java` for running the program.

## Tutorial

Checkout the following tutorial for this application -

<https://www.callicoder.com/javafx-registration-form-gui-tutorial/>